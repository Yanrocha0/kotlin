package com.example.jogodavelha

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.jogodavelha.databinding.ActivityIniciarBinding

class IniciarActivity : AppCompatActivity() {
    private lateinit var binding: ActivityIniciarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIniciarBinding.inflate(layoutInflater)
          // Certifique-se de que estamos configurando o conteúdo com a raiz do layout inflado

        binding.btnContraMaquina.setOnClickListener {   val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("modoDeJogo", "contraMaquina")
            startActivity(intent) }


        binding.btnContraAmigo.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("modoDeJogo", "contraAmigo")
            startActivity(intent)
        }
    }
}
