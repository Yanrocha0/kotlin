package com.example.jogodavelha

import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.jogodavelha.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    val tabuleiro = arrayOf(
        arrayOf("A", "B", "C"),
        arrayOf("D", "E", "F"),
        arrayOf("G", "H", "I")
    )

    var jogadorAtual = "X"
    var modoDeJogo: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        modoDeJogo = intent.getStringExtra("modoDeJogo")
    }

    fun buttonClick(view: View) {
        val buttonSelecionado = view as Button
        when (buttonSelecionado.id) {
            binding.buttonZero.id -> tabuleiro[0][0] = jogadorAtual
            binding.buttonUm.id -> tabuleiro[0][1] = jogadorAtual
            binding.buttonDois.id -> tabuleiro[0][2] = jogadorAtual
            binding.buttonTres.id -> tabuleiro[1][0] = jogadorAtual
            binding.buttonQuatro.id -> tabuleiro[1][1] = jogadorAtual
            binding.buttonCinco.id -> tabuleiro[1][2] = jogadorAtual
            binding.buttonSeis.id -> tabuleiro[2][0] = jogadorAtual
            binding.buttonSete.id -> tabuleiro[2][1] = jogadorAtual
            binding.buttonOito.id -> tabuleiro[2][2] = jogadorAtual
        }

        if (jogadorAtual == "X") {
            buttonSelecionado.setBackgroundResource(R.drawable.flamengo)
        } else {
            buttonSelecionado.setBackgroundResource(R.drawable.vasco)
        }

        buttonSelecionado.isEnabled = false

        val vencedor = verificaVencedor(tabuleiro)

        if (!vencedor.isNullOrBlank()) {
            Toast.makeText(this, "Vencedor: $vencedor", Toast.LENGTH_LONG).show()
            reiniciarJogo()
            return
        }

        if (modoDeJogo == "contraMaquina") {
            jogadorAtual = if (jogadorAtual == "X") "O" else "X"
            Handler().postDelayed({
                jogadaComputador()
            }, 1000)
        } else {
            jogadorAtual = if (jogadorAtual == "X") "O" else "X"
        }
    }

    private fun jogadaComputador() {
        var rX: Int
        var rY: Int
        var i = 0

        rX = 0
        rY = 0

        while (i < 9) {
            rX = Random.nextInt(0, 3)
            rY = Random.nextInt(0, 3)

            if (tabuleiro[rX][rY] != "X" && tabuleiro[rX][rY] != "O") {
                break
            }

            i++
        }

        tabuleiro[rX][rY] = "O"

        val posicao = rX * 3 + rY
        when (posicao) {
            0 -> binding.buttonZero.setBackgroundResource(R.drawable.vasco)
            1 -> binding.buttonUm.setBackgroundResource(R.drawable.vasco)
            2 -> binding.buttonDois.setBackgroundResource(R.drawable.vasco)
            3 -> binding.buttonTres.setBackgroundResource(R.drawable.vasco)
            4 -> binding.buttonQuatro.setBackgroundResource(R.drawable.vasco)
            5 -> binding.buttonCinco.setBackgroundResource(R.drawable.vasco)
            6 -> binding.buttonSeis.setBackgroundResource(R.drawable.vasco)
            7 -> binding.buttonSete.setBackgroundResource(R.drawable.vasco)
            8 -> binding.buttonOito.setBackgroundResource(R.drawable.vasco)
        }

        val vencedor = verificaVencedor(tabuleiro)

        if (!vencedor.isNullOrBlank()) {
            Toast.makeText(this, "Vencedor: $vencedor", Toast.LENGTH_LONG).show()
            reiniciarJogo()
        }

        jogadorAtual = if (jogadorAtual == "X") "O" else "X"
    }

    fun verificaVencedor(tabuleiro: Array<Array<String>>): String? {
        for (i in 0 until 3) {
            if (tabuleiro[i][0] == tabuleiro[i][1] && tabuleiro[i][1] == tabuleiro[i][2]) {
                return tabuleiro[i][0]
            }
            if (tabuleiro[0][i] == tabuleiro[1][i] && tabuleiro[1][i] == tabuleiro[2][i]) {
                return tabuleiro[0][i]
            }
        }
        if (tabuleiro[0][0] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][2]) {
            return tabuleiro[0][0]
        }
        if (tabuleiro[0][2] == tabuleiro[1][1] && tabuleiro[1][1] == tabuleiro[2][0]) {
            return tabuleiro[0][2]
        }
        var empate = 0
        for (linha in tabuleiro) {
            for (valor in linha) {
                if (valor == "X" || valor == "O") {
                    empate++
                }
            }
        }
        if (empate == 9) {
            return "Empate"
        }
        return null
    }

    private fun reiniciarJogo() {
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                tabuleiro[i][j] = i.toString() + j.toString()
            }
        }
        binding.buttonZero.setBackgroundResource(android.R.color.transparent)
        binding.buttonUm.setBackgroundResource(android.R.color.transparent)
        binding.buttonDois.setBackgroundResource(android.R.color.transparent)
        binding.buttonTres.setBackgroundResource(android.R.color.transparent)
        binding.buttonQuatro.setBackgroundResource(android.R.color.transparent)
        binding.buttonCinco.setBackgroundResource(android.R.color.transparent)
        binding.buttonSeis.setBackgroundResource(android.R.color.transparent)
        binding.buttonSete.setBackgroundResource(android.R.color.transparent)
        binding.buttonOito.setBackgroundResource(android.R.color.transparent)
        binding.buttonZero.isEnabled = true
        binding.buttonUm.isEnabled = true
        binding.buttonDois.isEnabled = true
        binding.buttonTres.isEnabled = true
        binding.buttonQuatro.isEnabled = true
        binding.buttonCinco.isEnabled = true
        binding.buttonSeis.isEnabled = true
        binding.buttonSete.isEnabled = true
        binding.buttonOito.isEnabled = true
        jogadorAtual = "X"
    }
}
