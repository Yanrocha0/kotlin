package com.example.jogodaforca

import android.content.DialogInterface
import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.jogodaforca.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val palavrasFacil = listOf("java", "html", "css")
    private val palavrasMedio = listOf("python", "react", "node")
    private val palavrasDificil = listOf("typescript", "graphql", "docker", "kotlin", "android", "desenvolvedor")

    private val dicas = mapOf(
        "JAVA" to listOf("Linguagem de programação popular e versátil.", "Usada em aplicações Android."),
        "HTML" to listOf("Linguagem de marcação para criar páginas web.", "Usada em conjunto com CSS e JavaScript."),
        "CSS" to listOf("Usada para estilizar páginas web.", "Permite criar layouts responsivos."),
        "PYTHON" to listOf("Linguagem de programação de alto nível.", "Muito usada em ciência de dados."),
        "REACT" to listOf("Biblioteca JavaScript para construir interfaces de usuário.", "Usada em desenvolvimento front-end."),
        "NODE" to listOf("Ambiente de execução JavaScript no lado do servidor.", "Usado para criar aplicações web escaláveis."),
        "TYPESCRIPT" to listOf("Superconjunto de JavaScript que adiciona tipagem estática.", "Popular em projetos grandes."),
        "GRAPHQL" to listOf("Linguagem de consulta para APIs.", "Permite solicitar apenas os dados necessários."),
        "DOCKER" to listOf("Plataforma para desenvolver, enviar e executar aplicações em contêineres.", "Facilita a portabilidade de aplicações."),
        "KOTLIN" to listOf("Linguagem de programação moderna da JetBrains.", "Compatível com Java."),
        "ANDROID" to listOf("Sistema operacional móvel do Google.", "Usado em dispositivos móveis."),
        "DESENVOLVEDOR" to listOf("Profissional que cria software.", "Pode atuar em diversas áreas."),
    )

    private lateinit var temporizador: CountDownTimer
    private var tempoRestante = 0
    private var tentativas = 6
    private val letrasAdivinhadas = mutableListOf<Char>()
    private lateinit var palavraSelecionada: String
    private lateinit var palavraOculta: CharArray
    private var nivelDificuldade = "facil"
    private var dicaUsada = 0 // Para rastrear o número de dicas usadas

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        nivelDificuldade = intent.getStringExtra("NIVEL_DIFICULDADE") ?: "facil"

        iniciarJogo()

        binding.buttonAdivinhar.setOnClickListener {
            val entrada = binding.editEntrada.text.toString().uppercase()
            if (entrada.isNotEmpty()) {
                val letra = entrada[0]
                if (!letrasAdivinhadas.contains(letra)) {
                    letrasAdivinhadas.add(letra)
                    if (palavraSelecionada.contains(letra)) {
                        for (i in palavraSelecionada.indices) {
                            if (palavraSelecionada[i] == letra) {
                                palavraOculta[i] = letra
                            }
                        }
                    } else {
                        tentativas--
                    }
                    binding.editEntrada.text.clear()
                    atualizarTela()
                }
            }
        }

        binding.buttonDica.setOnClickListener {
            if (dicaUsada < obterMaximoDicas()) {
                val dica = dicas[palavraSelecionada]?.get(dicaUsada)
                if (dica != null) {
                    binding.textDica.text = "Dica: $dica"
                    dicaUsada++
                    atualizarDicasRestantes()
                }
            } else {
                binding.textDica.text = "Todas as dicas já foram usadas"
            }
        }
    }

    private fun obterMaximoDicas(): Int {
        return when (nivelDificuldade) {
            "facil" -> 1
            "medio" -> 2
            else -> 3
        }
    }

    private fun iniciarJogo() {
        selecionarPalavra()
        iniciarTemporizador()
        atualizarTela()
    }

    private fun selecionarPalavra() {
        val lista = when (nivelDificuldade) {
            "facil" -> palavrasFacil
            "medio" -> palavrasMedio
            else -> palavrasDificil
        }

        palavraSelecionada = lista.random().uppercase()
        palavraOculta = CharArray(palavraSelecionada.length) { '_' }
    }

    private fun iniciarTemporizador() {
        tempoRestante = when (nivelDificuldade) {
            "facil" -> 60
            "medio" -> 45
            else -> 30
        }

        temporizador = object : CountDownTimer(tempoRestante * 1000L, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tempoRestante--
                binding.textTemporizador.text = "Tempo: $tempoRestante"
            }

            override fun onFinish() {
                binding.textStatus.text = "Tempo Esgotado! Era $palavraSelecionada"
                binding.buttonAdivinhar.isEnabled = false
                mostrarDialogoReiniciar()
            }
        }.start()
    }

    private fun atualizarTela() {
        binding.textOculto.text = palavraOculta.joinToString(" ")
        binding.textTentativas.text = "Restam: $tentativas"
        binding.textLetrasAdivinhadas.text = "Letras Adivinhadas: ${letrasAdivinhadas.joinToString(", ")}"
    }

    private fun atualizarDicasRestantes() {
        val dicasRestantes = obterMaximoDicas() - dicaUsada
        binding.textDica.text = "Dica: ${dicas[palavraSelecionada]?.getOrNull(dicaUsada) ?: "Todas as dicas já foram usadas"}"
    }

    private fun mostrarDialogoReiniciar() {
        AlertDialog.Builder(this)
            .setTitle("Jogo Acabou")
            .setMessage("Deseja jogar novamente?")
            .setPositiveButton("Sim") { _, _ ->
                // Resetar o estado do jogo
                tentativas = 6
                letrasAdivinhadas.clear()
                dicaUsada = 0
                // Reiniciar o jogo com seleção de dificuldade
                escolherDificuldade()
            }
            .setNegativeButton("Não") { _, _ ->
                finish() // Fechar o aplicativo
            }
            .show()
    }

    private fun escolherDificuldade() {
        AlertDialog.Builder(this)
            .setTitle("Escolha a Dificuldade")
            .setItems(arrayOf("Fácil", "Médio", "Difícil")) { _, which ->
                nivelDificuldade = when (which) {
                    0 -> "facil"
                    1 -> "medio"
                    else -> "dificil"
                }
                iniciarJogo()
            }
            .show()
    }
}
